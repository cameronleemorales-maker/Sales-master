# SalesMasterApp

## Build Locally
```bash
./gradlew assembleDebug
```
APK will be at `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
Workflow unzips `SalesMasterApp.zip`, runs `./gradlew assembleDebug`, uploads APK.

## API Key
Edit `ApiConfig.kt` and replace `PASTE-YOUR-KEY-HERE` with your OpenAI API key.
