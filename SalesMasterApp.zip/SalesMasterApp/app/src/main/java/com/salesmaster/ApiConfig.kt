package com.salesmaster

object ApiConfig {
    const val OPENAI_API_KEY = "PASTE-YOUR-KEY-HERE"
}
