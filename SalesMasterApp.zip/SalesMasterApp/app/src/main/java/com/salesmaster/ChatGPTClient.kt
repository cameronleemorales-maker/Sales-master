package com.salesmaster

import okhttp3.*
import org.json.JSONObject
import java.io.IOException

object ChatGPTClient {
    private val client = OkHttpClient()

    fun sendMessage(message: String, callback: (String) -> Unit) {
        val apiKey = ApiConfig.OPENAI_API_KEY
        if (apiKey == "PASTE-YOUR-KEY-HERE") {
            callback("⚠️ Please set your API key in ApiConfig.kt")
            return
        }

        val json = JSONObject()
        json.put("model", "gpt-3.5-turbo")
        json.put("messages", listOf(mapOf("role" to "user", "content" to message)))

        val body = RequestBody.create(MediaType.parse("application/json"), json.toString())

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .post(body)
            .addHeader("Authorization", "Bearer $apiKey")
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback("Error: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback("Unexpected code $it")
                    } else {
                        val responseBody = it.body()?.string()
                        val jsonResp = JSONObject(responseBody)
                        val reply = jsonResp.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                        callback(reply)
                    }
                }
            }
        })
    }
}
